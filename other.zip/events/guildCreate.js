const Discord = require("discord.js");

module.exports = class {

	constructor(client) {
		this.client = client;
	}

	async run(guild) {


		await guild.members.fetch();

		const guildOwner = await this.client.users.fetch(guild.ownerID).catch(() => { });

		const messageOptions = {};

		const userData = await this.client.findOrCreateUser({ id: guild.ownerID });

		const thanksEmbed = new Discord.MessageEmbed()
			.setAuthor("謝謝你將我加入你的伺服器!")
			.setDescription("如果你想配置我，輸入 `" + this.client.config.prefix + "help` 看看管理命令!\n如果想改變語言, 輸入 `" + this.client.config.prefix + "setlang [語言(zh-tw/en-us)]`.")
			.setColor(this.client.config.embed.color)
			.setFooter(this.client.config.embed.footer)
			.setTimestamp();
		messageOptions.embed = thanksEmbed;

		guildOwner?.send(messageOptions).catch(() => { });

		const text = "加入 **" + guild.name + "**, 共 **" + guild.members.cache.filter((m) => !m.user.bot).size + "** 個成員以及 (et " + guild.members.cache.filter((m) => m.user.bot).size + " 個Bots)";

		// Sends log embed in the logs channel
		const logsEmbed = new Discord.MessageEmbed()
			.setAuthor(guild.name, guild.iconURL())
			.setColor("#32CD32")
			.setDescription(text);
		this.client.channels.cache.get(this.client.config.support.logs).send(logsEmbed);
	}
};

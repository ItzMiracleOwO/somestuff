const chalk = require("chalk");

module.exports = class {

	constructor(client) {
		this.client = client;
	}

	async run() {

		const client = this.client;

		// Logs some informations using the logger file
		client.logger.log(`[CMD] 加載 ${client.commands.size} 個指令`, "log");
		client.logger.log(`${client.user.tag} 準備完成! 正在服務 ${client.guilds.cache.size} 個伺服器内的 ${client.users.cache.size} 個成員!`, "ready");


		/* UNMUTE USERS */
		const checkUnmutes = require("../helpers/checkUnmutes.js");
		checkUnmutes.init(client);

		/* SEND REMINDS */
		const checkReminds = require("../helpers/checkReminds.js");
		checkReminds.init(client);


		// Update the game every 20s
		const status = require("../config.js").status,
			version = require("../package.json").version;
		let i = 0;
		setInterval(function () {
			const toDisplay = status[parseInt(i, 10)].name.replace("{serversCount}", client.guilds.cache.size)
			client.user.setActivity(toDisplay, {
				type: status[parseInt(i, 10)].type
			});
			if (status[parseInt(i + 1, 10)]) i++;
			else i = 0;
		}, 20000); // Every 20 seconds


	}
};